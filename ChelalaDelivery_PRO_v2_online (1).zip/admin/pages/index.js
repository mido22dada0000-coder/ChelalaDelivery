import useSWR from 'swr'
const fetcher = (url) => fetch(url).then(r => r.json())
export default function Home(){
  const { data } = useSWR('https://chelala-delivery.onrender.com/api/v1/orders', fetcher)
  return (
    <main style={padding:20,fontFamily:'Arial'}>
      <h1>لوحة تحكم شلالة ديلفري</h1>
      <p>مرحبا بك، المسؤول. هذه واجهة تجريبية باللغة العربية.</p>
      <h2>الطلبات الحالية</h2>
      <pre>{JSON.stringify(data, null, 2)}</pre>
      <p>خريطة: (مكوّن الخريطة سيظهر هنا بعد الربط بمفتاح Google Maps)</p>
    </main>
  )
}
