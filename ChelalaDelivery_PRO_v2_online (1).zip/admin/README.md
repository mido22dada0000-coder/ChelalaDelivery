Chelala Delivery - Admin (Arabic)

To run locally:
1) cd admin
2) npm install
3) npm run dev

The admin calls the backend at https://chelala-delivery.onrender.com/api
Set Google Maps API key in the admin components to enable map features.
