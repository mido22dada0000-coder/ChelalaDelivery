Play Store Publishing Guide

Publisher: Mido Apps
Privacy policy: https://www.chelala.dz

Steps to publish:
- Generate signed AAB from Android Studio
- Create new app in Play Console and upload AAB
- Add store listing (title, description Arabic & English), screenshots, and icon
- Provide privacy policy URL and contact email
