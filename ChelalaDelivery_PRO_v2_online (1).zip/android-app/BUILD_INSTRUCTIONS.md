Build & Release (Chelala Delivery - PRO v2 Online)

1) Open android-app in Android Studio.
2) Ensure you set the Google Maps API key in local properties and grant location permissions.
3) Build debug APK for testing (signed with debug key) OR generate release AAB for Play Store.
4) For release, create keystore and sign the AAB.
5) Confirm that BACKEND_URL (https://chelala-delivery.onrender.com) is reachable from devices (no localhost when testing on real devices).
