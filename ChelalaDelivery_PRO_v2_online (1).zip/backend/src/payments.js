// Mock payments module (CIB / EDAHABIA / CASH)
// Replace with provider API calls when credentials available.
async function initiatePayment(data){
  const { method, amount_dzd, orderId } = data;
  if(!method || !amount_dzd) throw new Error('method and amount_dzd required');
  if(method === 'CASH') {
    return { success: true, method: 'CASH', status: 'pending', message: 'الدفع نقدًا عند التسليم', amount_dzd };
  }
  if(method === 'CIB') {
    return { success: true, method: 'CIB', provider: 'CIB (mock)', status: 'processing', amount_dzd, payment_url: `https://mock.cib.dz/pay?order=${orderId||'N/A'}&amount=${amount_dzd}` };
  }
  if(method === 'EDAHABIA') {
    return { success: true, method: 'EDAHABIA', provider: 'EDAHABIA (mock)', status: 'processing', amount_dzd, payment_code: `ED-${Math.floor(Math.random()*900000+100000)}` };
  }
  return { success:false, error:'unsupported method' };
}

async function verifyPayment(data){
  return { success:true, verified:true, data };
}

module.exports = { initiatePayment, verifyPayment };
