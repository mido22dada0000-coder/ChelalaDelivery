// Chelala Delivery Backend (Render-ready)
// Configured to run on port 3000 and connect to Postgres via DATABASE_URL
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const payments = require('./payments');
const adminData = require('./data/admin.json');

const app = express();
app.use(cors());
app.use(bodyParser.json());

let admins = [adminData.admin];
let orders = [];
let id = 1;

app.post('/api/v1/auth/login', (req,res)=>{
  const { email, password } = req.body;
  const admin = admins.find(a => a.email === email && a.password === password);
  if(admin) return res.json({ success:true, user: { email: admin.email, role: admin.role, name: admin.name }, token: 'mock-jwt-token' });
  return res.status(401).json({ success:false, message: 'Invalid credentials' });
});

app.post('/api/v1/orders', (req,res)=>{
  const { customer, items, total_dzd, pickup, dropoff } = req.body;
  const order = { id: id++, customer, items, total_dzd, pickup, dropoff, status:'new', created_at: new Date() };
  orders.push(order);
  res.json({ success:true, order });
});

app.get('/api/v1/orders', (req,res)=> res.json({ orders }));

app.post('/api/v1/payments/initiate', async (req,res)=>{
  try{
    const result = await payments.initiatePayment(req.body);
    res.json(result);
  } catch(e){
    res.status(500).json({ error: e.message });
  }
});

app.post('/api/v1/payments/verify', async (req,res)=>{
  const result = await payments.verifyPayment(req.body);
  res.json(result);
});

app.get('/api/v1/ping', (req,res)=> res.send('pong'));

const port = process.env.PORT || 3000;
app.listen(port, ()=> console.log('Backend listening on', port));
