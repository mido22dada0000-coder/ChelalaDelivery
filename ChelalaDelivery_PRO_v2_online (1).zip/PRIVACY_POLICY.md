Privacy Policy — Chelala Delivery
Website: https://www.chelala.dz
Contact: support@chelala.dz

(Please replace contact details with your official support address.)
